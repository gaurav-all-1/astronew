import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'molla-return-exchange',
  templateUrl: './returnexchange.component.html',
  styleUrls: ['./returnexchange.component.scss']
})
export class ReturnExchangeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
