import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'molla-cancelpolicy',
  templateUrl: './cancelpolicy.component.html',
  styleUrls: ['./cancelpolicy.component.scss']
})
export class CancelpolicyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
