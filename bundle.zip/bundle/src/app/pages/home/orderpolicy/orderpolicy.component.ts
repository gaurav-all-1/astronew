import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'molla-orderpolicy',
  templateUrl: './orderpolicy.component.html',
  styleUrls: ['./orderpolicy.component.scss']
})
export class OrderPolicyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
