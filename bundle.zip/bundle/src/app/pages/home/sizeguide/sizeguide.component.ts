import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'molla-sizeguide',
  templateUrl: './sizeguide.component.html',
  styleUrls: ['./sizeguide.component.scss']
})
export class SizeguideComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
