function sendConversion(){
    gtag('event', 'conversion', {
        'send_to': 'AW-11002071027/r6iYCJ_evoIYEPOPmf4o',
        'value': 1.0,
        'currency': 'INR',
        'transaction_id': ''
    });
}

function sendCartConversion()
{
    gtag('event', 'conversion', {
        'send_to': 'AW-11002071027/gglFCKXxvYIYEPOPmf4o',
        'value': 1.0,
        'currency': 'INR'
    });
}